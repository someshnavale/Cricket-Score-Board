package com.cricketpe.exceptions;

public class GenericExceptions {
}
